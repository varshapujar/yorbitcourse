﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Techademy.Assignment.Utility
{
    class LogFile
    {
        public static void LogInformation(string str)
        {
            Console.WriteLine(str);
        }

        public static void LogErrorInformation(string str)
        {
            Console.WriteLine(str);
        }
    }
}
