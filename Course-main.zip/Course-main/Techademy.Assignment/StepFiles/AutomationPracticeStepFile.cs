﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Techademy.Assignment.Utility;
using TechTalk.SpecFlow;

namespace Techademy.Assignment.StepFiles
{
    [Binding]
    class AutomationPracticeStepFile
    {
        ReusableMethods reusableMethods = new ReusableMethods();

        [Given(@"launch the url")]
        public void GivenLaunchTheUrl()
        {
            reusableMethods.launchUrl("https://www.airasia.com/en/gb");
            LogFile.LogInformation("Url is launched successfully");
            Thread.Sleep(5000);
        }


        [Given(@"launch the url of travel site")]
        public void GivenLaunchTheUrlTravelSite()
        {
            reusableMethods.launchUrl("https://newtours.demoaut.com/mercuryWelcome.php");
            LogFile.LogInformation("Url is launched successfully");
            Thread.Sleep(5000);
        }
        [Given(@"launch the url of automation practice")]
        public void GivenLaunchTheUrlAutomationPractice()
        {
            reusableMethods.launchUrl("https://automationpractice.com/index.php");
            LogFile.LogInformation("Url is launched successfully");
            Thread.Sleep(5000);
        }

        [When(@"I click on flights icon")]
        public void WhenIClickOnFlightsIcon()
        {
            reusableMethods.ClickByXPath("//img[@alt='Flights']");
            LogFile.LogInformation("Clicked on flight icon");
            Thread.Sleep(5000);
        }

        [When(@"enter details to search")]
        public void WhenEnterDetailsToSearch()
        {
            IWebElement a = reusableMethods.driver.FindElement(By.XPath("//input[@id='origin']"));
            Thread.Sleep(2000);
            a.Click();
            LogFile.LogInformation("Clicked on origin");
            Thread.Sleep(2000);
            a.Clear();
            LogFile.LogInformation("Cleared the origin field");
            Thread.Sleep(2000);
            a.SendKeys("Bengaluru BLR");
            Thread.Sleep(2000);
            reusableMethods.driver.FindElement(By.XPath("//input[@id='destination']")).SendKeys("Pune PNQ");
            Thread.Sleep(2000);
            LogFile.LogInformation("Destination is entered");
            reusableMethods.driver.FindElement(By.XPath("//input[@placeholder='dd/mm/yyyy']")).SendKeys("15/12/2018");
            LogFile.LogInformation("Depart date is entered");
            Thread.Sleep(2000);
            reusableMethods.driver.FindElement(By.XPath("(//input[@placeholder='dd/mm/yyyy'])[2]")).SendKeys("One Way");
            LogFile.LogInformation("Return date is entered");
        }

        [When(@"I click on search button")]
        public void WhenIClickOnSearchButton()
        {
            reusableMethods.ClickByXPath("//a[text()='Search']");
            LogFile.LogInformation("Clicked on search button");
        }

        [Then(@"I verify the title ""(.*)"" of application")]
        public void ThenIVerifyTheTitleOfApplication(string title)
        {
            string expected = reusableMethods.driver.Title;
            Assert.IsTrue(expected.Contains(title));
            LogFile.LogInformation("Title is verified");
        }

        [Then(@"I verify the search flight page ""(.*)""")]
        public void ThenIVerifyTheSearchFlightPage(string search)
        {
            string expected = reusableMethods.GetElementTextByXPath("(//span[text()='Price trends'])[2]");
            Assert.AreEqual(expected, search);
            LogFile.LogInformation("Search page is verified successfully");
        }
        [When(@"I click on login button")]
        public void WhenIClickOnLoginButton()
        {
            reusableMethods.ClickByXPath("//p[text()='Login/Signup']");
            LogFile.LogInformation("Clicked on login button");
        }

        [When(@"enter invalid user details")]
        public void WhenEnterInvalidUserDetails()
        {
            reusableMethods.TypeValueInTextFieldByXPath("//input[@id='text-input--login']", "a@gmail.com");
            LogFile.LogInformation("Username is entered");
            reusableMethods.TypeValueInTextFieldByXPath("//input[@id='password-input--login']", "India1234");

        }

        [When(@"I click on sign in button")]
        public void WhenIClickOnSignInButton()
        {
            reusableMethods.ClickByXPath("//input[@id='loginbutton']");
            LogFile.LogInformation("Clicked on login button");
        }

        [Then(@"I verify the error message ""(.*)""")]
        public void ThenIVerifyTheErrorMessage(string p0)
        {
            string expected = reusableMethods.GetElementTextByXPath("//div[contains(text(),'Your log in attempts has been unsuccessful')]");
            Assert.IsTrue(expected.Contains(p0));
            LogFile.LogInformation("Error message is verified successfully");
        }
        [When(@"I click on register link")]
        public void WhenIClickOnRegisterLink()
        {
            reusableMethods.ClickByID("register01");
            LogFile.LogInformation("Clicked on register link");
        }

        [When(@"I enter ""(.*)"" and ""(.*)""")]
        public void WhenIEnterAnd(string p0, string p1)
        {
            reusableMethods.TypeValueInTextFieldByID("fname01", p0);
            LogFile.LogInformation("First name is entered");
            reusableMethods.TypeValueInTextFieldByID("lname01", p1);
            LogFile.LogInformation("Last name is entered");
        }

        [When(@"I enter other mandatory details")]
        public void WhenIEnterOtherMandatoryDetails()
        {
            reusableMethods.TypeValueInTextFieldByID("phone01", "432567");
            LogFile.LogInformation("Phone number is entered");
            reusableMethods.TypeValueInTextFieldByID("Email01", "abc@gmail.com");
            LogFile.LogInformation("Email is entered");
            reusableMethods.TypeValueInTextFieldByID("address01", "7th cross street");
            LogFile.LogInformation("Address is entered");
            reusableMethods.TypeValueInTextFieldByID("city01", "bangalore");
            LogFile.LogInformation("City is entered");
            reusableMethods.TypeValueInTextFieldByID("state01", "Karnataka");
            LogFile.LogInformation("State value is entered");
            reusableMethods.TypeValueInTextFieldByID("post01", "908789");
            LogFile.LogInformation("Postal code is entered");
            reusableMethods.TypeValueInTextFieldByID("country01", "India");
            LogFile.LogInformation("Country is entered");
            reusableMethods.TypeValueInTextFieldByID("username01", "abcCutomerUser10");
            LogFile.LogInformation("User name is entered");
            reusableMethods.TypeValueInTextFieldByID("pwd01", "abc@123");
            LogFile.LogInformation("password is entered");
            reusableMethods.TypeValueInTextFieldByID("confirmpwd01", "abc@123");
            LogFile.LogInformation("Password is confirmed");



        }

        [When(@"I click on submit button")]
        public void WhenIClickOnSubmitButton()
        {
            reusableMethods.ClickByID("submkt01");
            LogFile.LogInformation("Clicked on submit button");
        }
        [When(@"I click on create account")]
        public void WhenIClickOnCreateAccount()
        {
            reusableMethods.ClickByID("CreatAccount01");
            LogFile.LogInformation("Clicked on create account");
        }

        [When(@"I enter the valid ""(.*)"" address")]
        public void WhenIEnterTheValidAddress(string p0)
        {
            reusableMethods.TypeValueInTextFieldByID("email09", p0);
            LogFile.LogInformation("Email is entered");
        }

        [When(@"I click on register button")]
        public void WhenIClickOnRegisterButton()
        {
            reusableMethods.ClickByID("register01");
            LogFile.LogInformation("Clicked  on register button");
        }

        [Then(@"I validate the registration page ""(.*)""")]
        public void ThenIValidateTheRegistrationPage(string a1)
        {
            string expected = reusableMethods.GetElementTextByID("registraion01");
            Assert.AreEqual(expected, a1);
            LogFile.LogInformation("Registration page is validated");
        }

        [When(@"I select title radio button")]
        public void WhenISelectTitleRadioButton()
        {
            reusableMethods.ClickByID("title01");
            LogFile.LogInformation("Title radio button is selected");
        }

        [When(@"I enter ""(.*)"" and ""(.*)"" and ""(.*)"" for registration")]
        public void WhenIEnterAndAndForRegistration(string p0, string p1, string p2)
        {
            reusableMethods.TypeValueInTextFieldByID("fname", p0);
            LogFile.LogInformation("First name is entered");
            reusableMethods.TypeValueInTextFieldByID("lname", p1);
            LogFile.LogInformation("last name is entered");
            reusableMethods.TypeValueInTextFieldByID("pwd", p2);
            LogFile.LogInformation("Password is entered");
        }

        [Then(@"I validate the registered user")]
        public void ThenIValidateTheRegisteredUser()
        {
            reusableMethods.IsElementDisplayedByID("Alertmessage");
            LogFile.LogInformation("User created successfully");
        }


    }
}

    

